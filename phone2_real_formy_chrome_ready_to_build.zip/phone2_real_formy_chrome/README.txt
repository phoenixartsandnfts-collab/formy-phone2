REAL FORMY + CHROME TEST

This project is different from the previous WebView project:
- Phone 2 opens the real Formy URL in Google Chrome:
  https://formy-project.herokuapp.com/form
- The Android controller listens only to Chrome.
- Phone 1 sends a deterministic command to the relay.
- The controller reads Chrome's accessibility tree and performs the fixed Formy test actions.

IMPORTANT LIMITATION
--------------------
Android AccessibilityService is a privileged feature and Google restricts its use.
Android documents that accessibility services can act on behalf of users, while Google
Play requires automation uses to have a narrow, clearly understood purpose. Autonomous
general-purpose automation is prohibited; deterministic, human-defined scripts are the
allowed automation pattern described by Google Play.

Therefore this project is intentionally narrow: it targets Chrome and a fixed Formy test
flow. It is not a general automation engine.

SETUP
-----
1. Open the project in Android Studio.
2. This version is already configured for:
      Relay: https://pixl.gt.tc/relay.php
      Test key: FORMY-TEST-2026
3. Build and install the APK on Phone 2. This package includes a GitHub Actions workflow so it can be built in the cloud without a computer.
4. Open the app.
5. Tap "Open Accessibility Settings".
6. Turn ON "Phone 2 Formy Controller".
7. Return to the app and tap "Open Real Formy in Chrome".
8. Keep the real Formy form visible in Chrome.
9. Put your own Phone 1 website on the relay URL and use the same API key.
10. Press Continue on Phone 1.

The first implementation fills the main editable text fields and clicks Submit.
The radio buttons, checkboxes and select menu need to be matched against the exact
accessibility tree on the Chrome/Formy version on your device before automating them.

Do not use this to bypass CAPTCHA, login/2FA, payment security, rate limits, or other
access controls on a third-party site.
