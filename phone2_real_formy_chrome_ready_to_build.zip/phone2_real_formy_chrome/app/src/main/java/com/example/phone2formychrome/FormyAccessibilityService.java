package com.example.phone2formychrome;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.text.TextUtils;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FormyAccessibilityService extends AccessibilityService {
    private static final String RELAY_URL = "https://pixl.gt.tc/relay.php?key=FORMY-TEST-2026";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private long lastEventId = 0;

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            pollRelay();
            handler.postDelayed(this, 800);
        }
    };

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        handler.post(poll);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    private void pollRelay() {
        executor.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(RELAY_URL);
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(5000);
                c.setReadTimeout(5000);
                if (c.getResponseCode() != 200) return;

                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder s = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) s.append(line);
                br.close();

                JSONObject response = new JSONObject(s.toString());
                JSONObject e = response.optJSONObject("event");
                if (e == null) return;

                String idText = e.optString("id", "0");
                long id;
                try { id = Long.parseLong(idText); } catch (Exception ex) { id = e.optLong("createdAt", 0); }
                if (id <= lastEventId) return;
                lastEventId = id;

                JSONObject fields = e.optJSONObject("fields");
                if (fields == null) return;

                // Only execute the static, human-defined Formy test script.
                getMainExecutor().execute(() -> applyFormy(fields, e.optString("action", "continue")));
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private void applyFormy(JSONObject f, String action) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        // Chrome is the only package this service listens to.
        // Find editable nodes in the visible Formy page in DOM/accessibility order.
        List<AccessibilityNodeInfo> edits = new ArrayList<>();
        collectEditable(root, edits);

        // Formy order: first name, last name, job title, date.
        setNth(edits, 0, f.optString("firstName", null));
        setNth(edits, 1, f.optString("lastName", null));
        setNth(edits, 2, f.optString("jobTitle", null));

        // The date field is usually later in the form. Find it by nearby text/content description.
        AccessibilityNodeInfo date = findByTextOrHint(root, "Date");
        if (date != null && f.has("date")) {
            date.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
                android.os.Bundle.EMPTY);
            setText(date, f.optString("date"));
        }

        // Radio/checkbox and select controls can vary with Chrome's accessibility tree.
        // The deterministic first phase deliberately handles text fields only.
        // Submit is only attempted when explicitly triggered by Phone 1.
        if ("continue".equals(action)) {
            AccessibilityNodeInfo submit = findClickableText(root, "Submit");
            if (submit != null) submit.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
    }

    private void collectEditable(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out) {
        if (n == null) return;
        if (n.isEditable()) out.add(n);
        for (int i=0; i<n.getChildCount(); i++) collectEditable(n.getChild(i), out);
    }

    private void setNth(List<AccessibilityNodeInfo> nodes, int index, String value) {
        if (value == null || index >= nodes.size()) return;
        setText(nodes.get(index), value);
    }

    private void setText(AccessibilityNodeInfo node, String value) {
        if (node == null || value == null) return;
        android.os.Bundle b = new android.os.Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    private AccessibilityNodeInfo findClickableText(AccessibilityNodeInfo n, String wanted) {
        if (n == null) return null;
        CharSequence t = n.getText();
        if (t != null && wanted.equalsIgnoreCase(t.toString().trim()) && n.isClickable()) return n;
        for (int i=0; i<n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findClickableText(n.getChild(i), wanted);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo findByTextOrHint(AccessibilityNodeInfo n, String wanted) {
        if (n == null) return null;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if ((t != null && t.toString().toLowerCase().contains(wanted.toLowerCase())) ||
            (d != null && d.toString().toLowerCase().contains(wanted.toLowerCase()))) return n;
        for (int i=0; i<n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findByTextOrHint(n.getChild(i), wanted);
            if (r != null) return r;
        }
        return null;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        executor.shutdownNow();
        super.onDestroy();
    }
}
