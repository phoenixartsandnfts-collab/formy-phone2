package com.example.phone2formychrome;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String FORMY_URL = "https://formy-project.herokuapp.com/form";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = 32;
        box.setPadding(p,p,p,p);

        TextView info = new TextView(this);
        info.setText(
            "Phone 2 Controller\n\n" +
            "1. Enable this app's accessibility service.\n" +
            "2. Open the REAL Formy site in Chrome.\n" +
            "3. Keep Chrome on the Formy form.\n" +
            "4. Phone 1 sends a deterministic test command.\n\n" +
            "This app only targets Chrome and the Formy test flow."
        );
        box.addView(info);

        Button settings = new Button(this);
        settings.setText("Open Accessibility Settings");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(settings);

        Button formy = new Button(this);
        formy.setText("Open Real Formy in Chrome");
        formy.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(FORMY_URL));
            i.setPackage("com.android.chrome");
            try { startActivity(i); }
            catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(FORMY_URL))); }
        });
        box.addView(formy);

        setContentView(box);
    }
}
